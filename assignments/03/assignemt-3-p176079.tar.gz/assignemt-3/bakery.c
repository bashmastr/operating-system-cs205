#include "pthread.h" 
  
#include "stdio.h" 
 
#include "unistd.h" 
  
#include "string.h" 

#define MEMBAR __sync_synchronize() 
#define THREAD_COUNT 8 
  
 int tic[THREAD_COUNT]; 
 int choose[THREAD_COUNT]; 
  
 int resource; 
  
void lock(int thread) 
{ 
    choose[thread] = 1; 
  
    MEMBAR; 
  
    int max_ticket = 0; 
  
    for (int i = 0; i < THREAD_COUNT; ++i) { 
  
        int ticket = tic[i]; 
        max_ticket = ticket > max_ticket ? ticket : max_ticket; 
    } 
  
    tic[thread] = max_ticket + 1; 
  
    MEMBAR; 
    choose[thread] = 0; 
    MEMBAR; 
  
    for (int other = 0; other < THREAD_COUNT; ++other) { 
  
        while (choose[other]) { 
        } 
  
        MEMBAR; 
  
        while (tic[other] != 0 && (tic[other] 
                                           < tic[thread] 
                                       || (tic[other] 
                                               == tic[thread] 
                                           && other < thread))) { 
        } 
    } 
} 
 
void unlock(int thread) 
{ 
  
    MEMBAR; 
    tic[thread] = 0; 
} 
  
void use_resource(int thread) 
{ 
  
    if (resource != 0) { 
        printf("Resource was acquired by %d, but is still in-use by %d!\n", 
               thread, resource); 
    } 
  
    resource = thread; 
    printf("%d using resource...\n", thread); 
  
    MEMBAR; 
    sleep(2); 
    resource = 0; 
} 
  
void* thread_body(void* arg) 
{ 
  
    long thread = (long)arg; 
    lock(thread); 
    use_resource(thread); 
    unlock(thread); 
    return NULL; 
} 
  
int main(int argc, char** argv) 
{ 
  
    memset((void*)tic, 0, sizeof(tic)); 
    memset((void*)choose, 0, sizeof(choose)); 
    resource = 0; 
  
    pthread_t threads[THREAD_COUNT]; 
  
    for (int i = 0; i < THREAD_COUNT; ++i) { 

        pthread_create(&threads[i], NULL, &thread_body, (void*)((long)i)); 
    } 
  
    for (int i = 0; i < THREAD_COUNT; ++i) { 

        pthread_join(threads[i], NULL); 
    } 
  
    return 0; 
} 
