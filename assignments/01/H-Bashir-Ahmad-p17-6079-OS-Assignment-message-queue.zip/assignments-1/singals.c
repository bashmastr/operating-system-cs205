#include <signal.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/ipc.h>
#include <sys/msg.h>
  

struct mes_struct{
	long mes_type;
	char mes_text[50];
}message;

void message_add_in_queue(){

	key_t key;
	int mesg_id;

	key = ftok("file",65);

	mesg_id = msgget(key,0666 | IPC_CREAT);
	message.mes_type = 1;

	printf("Enter data : ");
	gets(message.mes_text);  

	msgsnd(mesg_id, &message , sizeof(message), 0);

	printf("Data sended : %s\n",message.mes_text );


}

void message_recev_from_queue(){
	
	key_t key;
	int mesg_id;

	key = ftok("file" , 65);


	mesg_id = msgget(key , 0666 | IPC_CREAT);

	msgrcv(mesg_id, &message, sizeof(message), 1, 0);

	printf("Data recevied : %s\n", message.mes_text );

	msgctl(mesg_id, IPC_RMID, NULL);

}

int main(){

	message_add_in_queue();
	message_recev_from_queue();
		
	return 0;
}